
<html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<title>Wohlig Web Solutions Under Construction</title>
</head>

<body>
<div style="margin:0 auto;width:800px;">
<img src="<?php echo base_url('/assets/img/under_construction.jpg'); ?>" style="width:800px;">
</div>
</body></html>