<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['protocol'] = 'mail';
$config['charset'] = 'iso-8859-1';
$config['wordwrap'] = TRUE;
