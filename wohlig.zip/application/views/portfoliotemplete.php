<?php 
	$this->load->view('portfoliofiles/header');
	$this->load->view('portfoliofiles/'.$page);
	$this->load->view('portfoliofiles/footer');
?>