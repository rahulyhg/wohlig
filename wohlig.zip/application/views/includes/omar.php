<h3>Omar Khan
<span class="desig">Marketing | Philosopher | Visionary</span>
</h3>
<p>Omar Khan, after completion of his Engineering career, he got into Web Solutions industry as he nurtures his skill and talent in providing Web services to the clients.</p><p>He is excellent in marketing, client relationship and is the Socrates of our company. He should have been an orator as he speaks a lot, even best of the girls can't beat him. He is huge fan of Steve Jobs, Shahrukh Khan and Sachin Tendulkar. We don't have much to say about him as he either works or is inclined in spirituality. </p>
<p>He has worked really well like an Entrepreneur to get the company at this position.</p>
<p>Contact: +91 9833 190275 | omar@wohlig.com.</p>