<h3>Sapana Basutkar
<span class="desig">Web Designer</span>
</h3>
<p>The seedhi saadi chori of the group who is a crazy fan of all the retro movies like Hum aapke hai kaun, Hum saath saath hai, dil toh pagal hai etc. She is sweet, simple and always smiling. Loves her work and is always ready for challenges and opportunities. </p><p>A creative by heart, she is a pro at sketching and loves to dance and ride her bike. Though she is small, she excludes the confidence of a pofessional. An easy to talk and fun to be with person who has managed to make her place felt in Wohlig. A Salman Khan and Ajay Devgan fan and adores Kajol to the hilt. </p><p>A shant when needed and masti mein when the time is right, she is someone who is stubborn in her decisions and sure about her choices.</p>
<p> <b>Favourite movie -</b> "Hum aapke hai kaun?"</p>
<p> <b>Favourite Quote -</b> "Believe in God,Everything happens for a reason."</p>
<p> <b>One word for her -</b> "Simple"</p>
<!--<p><b>Contact:</b> +919029796018 | tushar@wohlig.com.</p>-->