
<h3> iPad Menu </h3>
<p>iPad menu is primarily made for guests who stay and need additional services like internet, entertainment-in-the-room, games for children and so on. This product has the capability to change the way a guest can be entertained apart from the conventional ways. Easy interactivity between the Hotel, Restaurant, Hospitals attendant and the guest is the main feature of this Product with a personalised touch.
</p>
<p>The application can be customised as per the business requirement and the user interactivity that the client wants.
</p>