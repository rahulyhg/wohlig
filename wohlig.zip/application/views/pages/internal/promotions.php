<h3>Promotions</h3>
<p>We offer promotions in order to meet following basic objectives:</p>
<ol>
  <li>To present information to consumers as well as others.</li>
  <li>To increase demand.</li>
  <li>To differentiate a product.</li>
</ol>
<p>Various promotions we offer are:</p>
<ul>
  <li>Personalised T-shirt</li>
  <li>Mug</li>
  <li>Pens</li>
  <li>Cap</li>
  <li>Card holder</li>
  <li>Gifts</li>
</ul>
