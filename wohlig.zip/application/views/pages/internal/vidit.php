<h3>Vidit Shah
<span class="desig">Marketing | App Developer</span>
</h3>
<p>Vidit Shah is an engineer by qualification however, he truly learnt how to do marketing in those 4 years of engineering for various events of the Students' Council. As the Gen. Secretary of the college he was truly an "Outstanding" student of the class i.e he would never be seen in the class.
</p>
<p>
Teachers would be surprised if he turned up for a class. He learnt most about engineering when he had to complete his B.E. project. He is a huge risk taker and sometimes takes more than he can handle.
</p>
<p> <b>Favorite Word:</b> "Awesome"</p>
<p><b>Contact:</b> +91 99200 81371 | vidit@wohlig.com</p>