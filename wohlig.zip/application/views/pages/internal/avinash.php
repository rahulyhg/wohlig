<h3>Avinash Ghare
<span class="desig">Backend Developer</span>
</h3>
<p>The person who thinks of himself as really boring and quiet, but he actually does talk quite a lot. Avinash is one of the developers in Wohlig who is passionate about his work and enjoys doing what he does. He loves singing and riding bikes whenever he gets an opportunity to do so. </p><p>A Ball-Badminton player, he likes outdoors more than indoors. A die hard cricket fan he is just another Sachin Tendulkar fan who live, dreams and breathes cricket. He likes to hand out with his friends and their favorite past time together is ‘bird watching’. </p>
<p> Though he comes across as quite chilled out, he is one big bhav khau and won’t open up that easily with people at first. he wants to become a good developer and wants to give his best for the team. The emotional and family oriented guy is quite the masti knor when you actually get to know him in person.</p>
<p> <b>Favorite movie -</b> "3 idiots"</p>
<p> <b>Favorite Quote -</b> "Love is everything. Embrace it and you'll find true happiness in life."</p>
<p> <b>One word for him -</b> "Dude"</p>
<p><b>Contact:</b> +918983454456 | avinash@wohlig.com</p>