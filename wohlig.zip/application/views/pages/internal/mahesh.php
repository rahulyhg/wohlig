<h3>Mahesh Maurya
<span class="desig">Web Developer | Web Designer | App Developer</span>
</h3>
<p>Another oldie in the group, but a complete bacha by heart. He has a funny laugh and an equally funny mind. He is a vampire who wakes up at 3am in the night for no apparent reason. His hobbies include gaming gaming and only gaming.his eyes go wide in excitement when he talks about his favourite games. </p><p>Though he is 26 he doesn’t behave like one, he enjoys teasing his team mates especially Sohan who quietly bares all the pranks that are inflicted upon him by Mahesh. He is a die-hard cricket fan who worships Sachin Tendulkar. He enjoys watching Hollywood movies and his favourite actor is Jason Statham. </p><p>He likes to party and work as well. He is a work-o-holic who gives his best in whatever he does. A person on which the team is proud and can rely on.</p>
<p> <b>Favorite movie -</b> "Thor"</p>
<p> <b>Favourite Quote -</b> "we all are trying to forget something. :("</p>
<p> <b>One word for him -</b> "Emphatic"</p>
<p><b>Contact:</b> +918796622179 | mahesh@wohlig.com</p>