<h3>Chintan Shah
<span class="desig">Web Developer | Web Designer | Marketing | App Developer</span>
</h3>
<p>When you look at him, you will see just another ordinary guy, when you talk to him, you will know that there is nothing ordinary about him. The co-founder of Wohlig is a person with a business brain, an enigmatic soul and a crazy game of thrones heart. </p><p>It is almost like he cannot wait to talk more about his favorite sitcom and make everyone believe that it is the most amazing thing that has happened on earth. Chintan is not interested in anything except his work. </p><p>He does not care about girls, guys or anything in between. He loves talking and working and is proud of his team. A disciplined person, who is always ready to tease his co workers, laughs at his own jokes and pull their legs.</p>
<p> <b>Favorite movie -</b> "The Prestige"</p>
<p> <b>Favorite quote -</b> "A problem is not the problem. Your attitude towards the problem is the problem."</p>
<p> <b>One word for him -</b> "Brainy"</p>
<p><b>Contact:</b> +919819222221 | chintan@wohlig.com</p>