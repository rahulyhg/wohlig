<h3>Dhaval Gala
<span class="desig">Web Developer | App Developer </span>
</h3>
<p>Another shant person of the group. Dhaval has always wanted to become a developer. In the 4th grade, when most people are too busy procastinating about becoming rockstars and sports men, Dhaval had made up his mind to become an engineer. </p><p>He claims that he has always been in love with engineering and the paraphenalia that comes along with it. Other than being an exceptional developer, he is also a foodie. He loves chinese and italian food and can devour tons of it any time and anywhere. The foodie and engineer also loves to be alone and listen to trance and soft music. </p><p>He claims that he is the always shant person who doesnt like to talk much, but he also sheepishly says that he is a total mumma's boy and a family person. He has his feet firmly set on the ground but his head is high among the clouds with dreams and ambitions which he is strongly believes in.</p>
<p> <b>Favorite movie -</b> "Fast and furious series"</p>
<p> <b>Favourite Quote -</b> "Positive anything is better than negative nothing"</p>
<p> <b>One word for him -</b> "Candid"</p>
<!--<p><b>Contact:</b> +918796622179 | mahesh@wohlig.com</p>-->