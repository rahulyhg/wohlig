<h3>Jagruti Patil
<span class="desig">Web Developer | App Developer</span>
</h3>
<p>A golden girl, she loves her work. She has always known that she wanted to be a developer as she thoroughly enjoys doing her work and being a developer. Though she is tiny, her dreams are huge and so is her intelligence. A perfect friend and a favorite of almost all the other team members, she surely knows how to win hearts and make a person comfortable no matter what the situation, she has an aura of gold and a heart so pure. </p><p>Though she is 24, she loves doing crazy things and is still in touch with the child inside. A sucker for perfection and a dedicated co-worker who gives her best in whatever she does. Though she is a developer, she has a lot of creativity stuck in her tiny self. .</p><p> An avid quiller and a fan of nemo she has a fish tank made of quilling with a nemo in it. She loves old hindi films especially the ones in which people do over-acting. A perfect friend and co-worker who is a pleasue to talk with.</p>
<p> <b>Favourite movie -</b> "Hum saath saath hai"</p>
<p> <b>Favourite quote -</b> "if you fail to plan, you plan to fail."</p>
<p> <b>One word for her -</b> "confusing"</p>
<p><b>Contact:</b> +919867274170 | jagruti@wohlig.com</p>