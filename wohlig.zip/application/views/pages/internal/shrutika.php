<h3>Shrutika Jadhav
<span class="desig">Web Developer | Web Designer | Marketing | App Developer</span>
</h3>
<p>Chintan Shah is the founder of Wohlig Web Solutions. He developed first website in 10th standard, he started his company while studding in 2nd Year of Engineering College. Bla Bla Bla... When you think of a nerd and the picture that comes in your mind will be quite similar to Chintan.</p><p>He is not interested in games, movies or girls. His favorite time pass is learning some new computer language, creating applications and reading some self-help books.  He is a good friend, hard working, but a complete bore. The last time he changed his Facebook profile was may be 2 or 3 years ago.</p>
<p> <b>Favorite Word:</b> "wow"</p>
<p><b>Contact:</b> +919867583282 | shrutika@wohlig.com</p>