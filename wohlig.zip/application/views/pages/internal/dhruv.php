<h3>Dhruv Dholakia |<span class="desig">Co-founder</span></h3>
<p>Handles business development at Wohlig.</p>
<p>He just loves what he does and so he's so enthusiastic of talking about his journey with Wohlig.</p>
<p>A go-getter. Has single belief- "I will Fail, & Fail again till I Succeed".</p>
<p>He's a visionary. A fast learner and more than that a fun-loving person to be with.</p>
<p>Supports causes that he doesn't like to disclose.</p>
<p>Knows his staff before he hires them.</p>
<p>His favourite quote- "Once in life do fall in love, not necessarily with a person, but with an idea, a dream, an ambition. More often it will be a reason to wake up with a smile"</p>
<p>Contact: +919029560949 | dhruv@wohlig.com.</p>