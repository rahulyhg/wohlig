<h3>Mobile app</h3>
<p>Mobile apps make the availability of data faster and easier with minimal effort and a great interactivity.
  We make mobile applications customised according to the business. The mobile apps that we develop are compatible to the following Mobile OS’s:</p>
<ul>
  <li>iOS</li>
  <li>Android</li>
  <li>Blackberry</li>
  <li>Windows</li>
  <li>Symbian</li>
</ul>
