<h3>Chirag Shah
<span class="desig"> CME </span>
</h3>
<p>Chirag is the oldest person in the group, and since he is the oldest he is the most boring person as well. His idea of having fun is perhaps working on his beloved Mac. He is extremly hard working, focussed and a complete money minded materialist. He is the marketing head of the group and he knows his work and all the tricks that come with it pretty well. </p><p>He hates writing and reading and anything that includes the use of books, however, he is a very serious and emotional person as compared to the other co-founders. But he knows how to hide his soft side pretty well, but his brother, Chintan knows what he is like and doesn't waste a single opportunity to tease him about it. </p><p>A person who believes in living the high life and not wasting a single opportunity to make it large.</p>
<p> <b>Favorite movie -</b> "Wolf of Wall Street"</p>
<p> <b>Favourite Quote -</b> "thinking..."</p>
<p> <b>One word for Chirag -</b> "SNOB"</p>
<p><b>Contact:</b> +919820045678 | chirag@wohlig.com</p>