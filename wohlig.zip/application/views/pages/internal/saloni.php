<h3>Saloni Jain
<span class="desig">Creative Content Writer, Art and Craft Professional, Musician, Project Manager and many more. </span>
</h3>
<p class="whl-p">It is always said there are some people who are quite secretive about themselves and some who are like an open

book, well she manages to be a third type, the “Wikipedia”.

You ask her about her hair and she will even tell you the origin of her hair molecules during the big bang and the

amount of energy needed to create matter for her hair as well.</p><p class="whl-p">She often speaks a lot, but anyways she has a very nice voice and she speak like tender sunlight at the time of sun

rise, but she quite overdo the sunshine make it into scorching heat after some point of time.

She is not the person you would like to offend as one should always have good relations with media.</p>
<p class="whl-p">She is cheerful, full of fun but is also fascinated with the past and enjoys it profoundly. She enjoys the early morning

dew on the petals of the flowers and also asteroid falls on the planet for annihilation in her own sense of way.

She has many precious possessions but she never cares for them, actually she does care, so let’s just say she has

many precious possessions.</p><p class="whl-p">There are several things that bothers her but money is certainly not in the list. May be? No not in list.

Most of us are born with a talent while some are not, well in that case she is The Da Vince of Modern times, but

she pretends to be ignorant of her potentials as she pretends to be or is humble enough to think of herself as

nothing more than a simple ordinary girl. As it’s said the sign of a true hero is humility.</p>
<p> <b>Favorite movie -</b> “Hum Saath Saath Hain"</p>
<p> <b>Favourite Quote -</b> "Its not because i want to, its because you said i can't."</p>
<p> <b>One word for her -</b>"da vinci"</p>
<!--<p><b>Contact:</b> +918796622179 | mahesh@wohlig.com</p>-->