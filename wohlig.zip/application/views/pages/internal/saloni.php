<h3>Saloni Jain
<span class="desig">Almost web developer </span>
</h3>
<p>The jhalli of the team. She loves to talk and she does talk alot. She is the ladki with the machoness within her. Though she portrays herself to be very strong and serious, she is a true softie by heart. She loves her family to the core and is very protective about her two sisters. </p><p>She considers IT as her passion and loves to work and take on different opportunities and tasks. A frequent in getting punished at school and college for talking and laughing, she has been a born mastikhor and has been called names like 'don' during college. </p><p>A free spirited girl who enjoys dancing and playing sports as much as she enjoys working with the team.</p>
<p> <b>Favorite movie -</b> "Andaz apna apna"</p>
<p> <b>Favourite Quote -</b> "Be so busy in improving yourself that you have no time in criticizing others. "</p>
<p> <b>One word for her -</b> "jhalli"</p>
<!--<p><b>Contact:</b> +918796622179 | mahesh@wohlig.com</p>-->