<h3>Tushar Sachde
<span class="desig">Graphic Designer | Web Designer | App Developer</span>
</h3>
<p>The kid of the firm. He is the lamest person in the group who just wont stop cracking lame jokes. Though he is just 21, he has been a part of Wohlig since 4 years. One of the co-founders who loves to work (only) on holidays and he is the one who is always responsible for delays in projects. </p><p> His favourite past time is eating, cracking lame jokes and watching movies. The other people in the team give him all the food that they cannot have and it is gone in a matter of minuites. He is disinterested in books or any form of literature. He is a gadget freak and loves gaming. </p><p> However, his designing skills and the way his creative mind works shows how capable and talented he is. He has managed to create the most extra ordinary designs for the websites and applications for the clients.</p>
<p> <b>Favourite movie -</b> "Dil Chahta hai"</p>
<p> <b>Favourite Quote -</b> "You dont know me, you are about to."</p>
<p> <b>One word for him -</b> "Smart"</p>
<p><b>Contact:</b> +919029796018 | tushar@wohlig.com.</p>