<h3>Vignesh Kasturi
<span class="desig">Trainee</span>
</h3>
<p>When you look at him, he will look like the quite guy who is so serious and dedicated. But once he opens up, Vignesh has more masti in him than most of the members in the group. He has done so many crazy things in his school and college life that he does not even remember the most crazy of them. </p><p>A person who is a die hard football fan, he enjoys playing and watching the game equally. His favourite movies are the subtle ones which are emotional and fun to watch. A person who surely takes time to open up, but once he does, he doesnot stop talking.  </p><p> He s a bada wala mastikhor who loves playing pranks and doing the most crazy and out of the world things. He is considered as the 'Comedy' in the family He loves programming and learning more about it at any given point of time. You can see how much he enjoys his work by the way he speaks about it.</p>
<p> <b>Favourite movie -</b> "2 states"</p>
<p> <b>Favourite Quote -</b> "Life is like an ice-cream, enjoy it before it melts."</p>
<p> <b>One word for him -</b> "Quite"</p>
<!--<p><b>Contact:</b> +919029796018 | tushar@wohlig.com.</p>-->