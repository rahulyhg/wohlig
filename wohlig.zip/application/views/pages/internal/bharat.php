<h3>
Bharat Rathod
<span class="desig">Web Developer | Mobile Application Developer</span>
</h3>
<p>
Bharat is an Electronic Engineer, but an exceptional PHP developer, quite a rare combination. You tell him to do anything on PHP and he will do it in minutes. Apart from all this quality there are some more qualities in him, quite amazing qualities viz. If you are a funny guy you should always have him near you, because even on the worst jokes on the planet this boy burst out laughing. He has even consulted a doctor but they both ended up laughing at each other. 
</p>
<p>Anyways, this actually helps, as when you lose confidence on your joke and even when you lose confidence on yourself, this person helps you to rebuild it. The only thing he hates a lot is cuss words. If you speak something like that before him, it will be the last time you would have said such a word. Extremely focused and never needs any help from any person, as he like to do all his work on his own. 
</p>
<p> <b>Favorite Word:</b> "hehehehahaha"</p>
<p><b>Contact:</b> +91 9773261064 | bharat@wohlig.com</p>