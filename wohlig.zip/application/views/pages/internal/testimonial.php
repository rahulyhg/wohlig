<p class="testiquote">"I am very satisfied with the website. If I will rate it from scale 1 to 10 and 10 is the best, I will give you the highest number. Thank You so much. Thanks again and I am very proud of the Website."
<span class="by">-Neeta Gala</span>
</p>

<p class="testiquote">"We are extremely happy with the professional and friendly service we receive from Wohlig. We would highly recommend them."
<span class="by">-Jatin Shah </span></p>

<p class="testiquote">Wohlig Web Solutions has provided us with a professional, personal and friendly service. Thank You."
<span class="by">-Tasneem</span>
</p>


<p class="testiquote">"Wohlig offered a great design for a competitive price. Very responsive and professional. Good sense of design and technical knowledge of web design. I will be using them again in the future!"
<span class="by">- Dipesh Dedhia</span>
</p>
