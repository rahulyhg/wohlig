<div class="row">
<div class="span12 center"> 
<div class="logotext">w<span class="logocircle" ></span><span style="display:none;">o</span>hlig</div>
</div>
</div>
<div class="row" >
	<div class="span3">
		<a href="<?php echo site_url('site/about');?>"><div class="circle changecolor" id="about"> <img src="<?php echo base_url('assets/img/about.png');?>" /> </div>
		<div class="circletext">about</div></a>
	</div>
	<div class="span3">
		<a href="<?php echo site_url('site/team');?>"><div class="circle changecolor" id="team"> <img src="<?php echo base_url('assets/img/team.png');?>" /> </div>
		<div class="circletext">team</div></a>
	</div>
	<div class="span3">
		<a href="<?php echo site_url('site/services');?>"><div class="circle changecolor" id="services"> <img src="<?php echo base_url('assets/img/services.png');?>" /> </div>
		<div class="circletext">services</div></a>
	</div>
	<div class="span3">
		<a href="<?php echo site_url('site/products');?>"><div class="circle changecolor" id="products"> <img src="<?php echo base_url('assets/img/products.png');?>" /> </div>
		<div class="circletext">products</div></a>
	</div>
</div>
<div class="row" style="margin-left:11%;">
	<div class="span3">
		<a href="<?php echo site_url('site/portfolio');?>"><div class="circle changecolor" id="portfolio"> <img src="<?php echo base_url('assets/img/portfolio.png');?>" /> </div>
		<div class="circletext">portfolio</div></a>
	</div>
	<div class="span3">
		<a href="<?php echo site_url('site/testimonial');?>"><div class="circle changecolor" id="testimonial"> <img src="<?php echo base_url('assets/img/testimonial.png');?>" /> </div>
		<div class="circletext">testimonial</div></a>
	</div>
	<div class="span3">
		<a href="<?php echo site_url('site/contact');?>"><div class="circle changecolor" id="contact"> <img src="<?php echo base_url('assets/img/contact.png');?>" /> </div>
		<div class="circletext">contact</div></a>
	</div>
</div>
