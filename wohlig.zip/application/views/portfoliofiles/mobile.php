<?php 
$folio[0]->header="91 Street: Home View";
$folio[1]->header="91 Street: Mall View";
$folio[2]->header="91 Street: Mall Details View";
$folio[3]->header="Politician: Home View";
$folio[4]->header="Politician: Video Gallery View";
$folio[5]->header="Politician: Facebook View";
$folio[6]->header="ROW: Home Screen";
$folio[7]->header="ROW: Side Menu";
$folio[8]->header="ROW: My Club";
$folio[9]->header="ROW: Clubs Near Me";
$folio[10]->header="ROW: News";
$folio[11]->header="ROW: Birthdays & Anniversary";
$folio[12]->header="ROW: Today's Events";
$folio[13]->header="ROW: Notifications";
$folio[14]->header="Mall Khoj: Home Screen of Mall Khoj";
$folio[15]->header="Mall Khoj: Mall View";
$folio[16]->header="Fit Lab: Home View";
$folio[17]->header="Fit Lab: Compare Video";
$folio[18]->header="Fit Lab: Video";
$folio[19]->header="Fit Lab: Review";


$folio[0]->img="mobile12";
$folio[1]->img="mobile14";
$folio[2]->img="mobile15";
$folio[3]->img="mobile11";
$folio[4]->img="mobile13";
$folio[5]->img="mobile16";
$folio[6]->img="mobile3";
$folio[7]->img="mobile2";
$folio[8]->img="mobile1";
$folio[9]->img="mobile4";
$folio[10]->img="mobile5";
$folio[11]->img="mobile6";
$folio[12]->img="mobile7";
$folio[13]->img="mobile8";
$folio[14]->img="mobile9";
$folio[15]->img="mobile10";
$folio[16]->img="mobile24";
$folio[17]->img="mobile25";
$folio[18]->img="mobile26";
$folio[19]->img="mobile27";



$folio[0]->description="91streets - shopping companion is a great shopping application which enables customers to locate stores, locate brands, follow brands and find great discounts when they plan to shop.";
$folio[1]->description="91streets - shopping companion is a great shopping application which enables customers to locate stores, locate brands, follow brands and find great discounts when they plan to shop.";
$folio[2]->description="91streets simplifies the shopping experience by helping the user to. Locate Stores, Locate Malls, Find Offers and discounts in stores, Find offers and discounts in malls, Follow Brands.";
$folio[3]->description="Poltician Apps Is Simple With Attractive User Interface. Showing Your Politician Details.There Is Many Feature in This App Like Schedule, Enquiry mail, YouTube Video, facebook, Twitter Likes.";
$folio[4]->description="In Politician Apps You Can Easly Watch Your Politician Video On YouTube.And You Can See Them tweet.Other Feature Is That You Can See Photos.";
$folio[5]->description="Favourite feature Is That You can Check facebook page.There are Lots of feature In This Like Next Meeting Schedule.You Can Join Easly With Membership Form.";
$folio[6]->description="ROW (Roster On Wheels) ";
$folio[7]->description="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, Codeignitor, Jquery Mobile, PhoneGap, Hammer.js, JQuery Validator, Adobe Photoshop, Adobe Illustrator.";
$folio[8]->description="A collection of textile samples lay spread out on the table - Samsa was a travelling salesman - and above it there hung a picture that he had recently cut out of an illustrated magazine and housed in a nice, gilded frame.";
$folio[9]->description="It showed a lady fitted out with a fur hat and fur boa who sat upright, raising a heavy fur muff that";
$folio[10]->description="A collection of textile samples lay spread out on the table - Samsa was a travelling salesman - and above it there hung a picture that he had recently cut out of an illustrated magazine and housed in a nice, gilded frame.";
$folio[11]->description="It showed a lady fitted out with a fur hat and fur boa who sat upright, raising a heavy fur muff that";
$folio[12]->description="A collection of textile samples lay spread out on the table - Samsa was a travelling salesman - and above it there hung a picture that he had recently cut out of an illustrated magazine and housed in a nice, gilded frame.";
$folio[13]->description="A collection of textile samples lay spread out on the table - Samsa was a travelling salesman - and above it there hung a picture that he had recently cut out of an illustrated magazine and housed in a nice, gilded frame.";
$folio[14]->description="A collection of textile samples lay spread out on the table - Samsa was a travelling salesman - and above it there hung a picture that he had recently cut out of an illustrated magazine and housed in a nice, gilded frame.";
$folio[15]->description="A collection of textile samples lay spread out on the table - Samsa was a travelling salesman - and above it there hung a picture that he had recently cut out of an illustrated magazine and housed in a nice, gilded frame.";
$folio[16]->description="A collection of textile samples lay spread out on the table - Samsa was a travelling salesman - and above it there hung a picture that he had recently cut out of an illustrated magazine and housed in a nice, gilded frame.";
$folio[17]->description="A collection of textile samples lay spread out on the table - Samsa was a travelling salesman - and above it there hung a picture that he had recently cut out of an illustrated magazine and housed in a nice, gilded frame.";
$folio[18]->description="A collection of textile samples lay spread out on the table - Samsa was a travelling salesman - and above it there hung a picture that he had recently cut out of an illustrated magazine and housed in a nice, gilded frame.";
$folio[19]->description="A collection of textile samples lay spread out on the table - Samsa was a travelling salesman - and above it there hung a picture that he had recently cut out of an illustrated magazine and housed in a nice, gilded frame.";





$folio[0]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, Ionic, Jquery Mobile, PhoneGap, Angularjs, JQuery Validator, Adobe Photoshop, Adobe Illustrator.";
$folio[1]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, Ionic, Jquery Mobile, PhoneGap, Angularjs, JQuery Validator, Adobe Photoshop, Adobe Illustrator.";
$folio[2]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, Ionic, Jquery Mobile, PhoneGap, Angularjs, JQuery Validator, Adobe Photoshop, Adobe Illustrator.";
$folio[3]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, Ionic, Jquery Mobile, PhoneGap, Angularjs, JQuery Validator, Adobe Photoshop, Adobe Illustrator.";
$folio[4]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, Ionic, Jquery Mobile, PhoneGap, Angularjs, JQuery Validator, Adobe Photoshop, Adobe Illustrator.";
$folio[5]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, Ionic, Jquery Mobile, PhoneGap, Angularjs, JQuery Validator, Adobe Photoshop, Adobe Illustrator.";
$folio[6]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, Codeignitor, Jquery Mobile, PhoneGap, Hammer.js, JQuery Validator, Adobe Photoshop, Adobe Illustrator.";
$folio[7]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, Codeignitor, Jquery Mobile, PhoneGap, Hammer.js, JQuery Validator, Adobe Photoshop, Adobe Illustrator.";
$folio[8]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, Codeignitor, Jquery Mobile, PhoneGap, Hammer.js, JQuery Validator, Adobe Photoshop, Adobe Illustrator.";
$folio[9]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, Codeignitor, Jquery Mobile, PhoneGap, Hammer.js, JQuery Validator, Adobe Photoshop, Adobe Illustrator.";
$folio[10]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, Codeignitor, Jquery Mobile, PhoneGap, Hammer.js, JQuery Validator, Adobe Photoshop, Adobe Illustrator.";
$folio[11]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, Codeignitor, Jquery Mobile, PhoneGap, Hammer.js, JQuery Validator, Adobe Photoshop, Adobe Illustrator.";
$folio[12]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, Codeignitor, Jquery Mobile, PhoneGap, Hammer.js, JQuery Validator, Adobe Photoshop, Adobe Illustrator.";
$folio[13]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, Codeignitor, Jquery Mobile, PhoneGap, Hammer.js, JQuery Validator, Adobe Photoshop, Adobe Illustrator.";
$folio[14]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, Ionic, Codeignitor, Jquery Mobile, PhoneGap, Hammer.js, JQuery Validator, Adobe Photoshop, Adobe Illustrator.";
$folio[15]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, Ionic, Codeignitor, Jquery Mobile, PhoneGap, Hammer.js, JQuery Validator, Adobe Photoshop, Adobe Illustrator.";
$folio[16]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, Codeignitor, Jquery Mobile, PhoneGap, Hammer.js, JQuery Validator, Adobe Photoshop, Adobe Illustrator.";
$folio[17]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, Ionic, Codeignitor, Jquery Mobile, PhoneGap, Hammer.js, JQuery Validator, Adobe Photoshop, Adobe Illustrator.";
$folio[18]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, Ionic, Codeignitor, Jquery Mobile, PhoneGap, Hammer.js, JQuery Validator, Adobe Photoshop, Adobe Illustrator.";
$folio[19]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, Ionic, Codeignitor, Jquery Mobile, PhoneGap, Hammer.js, JQuery Validator, Adobe Photoshop, Adobe Illustrator.";


?>

<?php
 $this->load->helper('portfolio'); 
 echo createportfolio($folio); 
?>
