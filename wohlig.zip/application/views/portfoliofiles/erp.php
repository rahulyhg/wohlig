<?php 

$folio[0]->header="Galaxy Optician: Login Page";
$folio[1]->header="Galaxy Optician: Stock Reports";
$folio[2]->header="Galaxy Optician: Add Product";
$folio[3]->header="Galaxy Optician: Create Invoice";
$folio[4]->header="Galaxy Optician: Edit Invoice";
$folio[5]->header="Galaxy Optician: Create Barcodes";
$folio[6]->header="Galaxy Optician: View Barcodes";
$folio[7]->header="5Times5: Login Page";
$folio[8]->header="5Times5: Create Bill";
$folio[9]->header="5Times5: View Bills";
$folio[10]->header="5Times5: Edit Bills";
$folio[11]->header="5Times5: Delivery Order";
$folio[12]->header="5Times5: Reports";
$folio[0]->img="erp1";
$folio[1]->img="erp2";
$folio[2]->img="erp3";
$folio[3]->img="erp4";
$folio[4]->img="erp5";
$folio[5]->img="erp6";
$folio[6]->img="erp7";
$folio[7]->img="erp8";
$folio[8]->img="erp9";
$folio[9]->img="erp10";
$folio[10]->img="erp11";
$folio[11]->img="erp12";
$folio[12]->img="erp13";


$folio[0]->description="ERP for one of the renowned Opticians in town. The System helps to manage stocks, Bar code reading of the stocks, Customer relationship, Account management, Access control for various users, Invoice generation and Statistical reports.";
$folio[1]->description="ERP for one of the renowned Opticians in town. The System helps to manage stocks, Bar code reading of the stocks, Customer relationship, Account management, Access control for various users, Invoice generation and Statistical reports.";
$folio[2]->description="ERP for one of the renowned Opticians in town. The System helps to manage stocks, Bar code reading of the stocks, Customer relationship, Account management, Access control for various users, Invoice generation and Statistical reports.";
$folio[3]->description="ERP for one of the renowned Opticians in town. The System helps to manage stocks, Bar code reading of the stocks, Customer relationship, Account management, Access control for various users, Invoice generation and Statistical reports.";
$folio[4]->description="ERP for one of the renowned Opticians in town. The System helps to manage stocks, Bar code reading of the stocks, Customer relationship, Account management, Access control for various users, Invoice generation and Statistical reports.";
$folio[5]->description="ERP for one of the renowned Opticians in town. The System helps to manage stocks, Bar code reading of the stocks, Customer relationship, Account management, Access control for various users, Invoice generation and Statistical reports.";
$folio[6]->description="ERP for one of the renowned Opticians in town. The System helps to manage stocks, Bar code reading of the stocks, Customer relationship, Account management, Access control for various users, Invoice generation and Statistical reports.";
$folio[7]->description="ERP for a General store wherein the system helps to manage the Stocks (various categories and sub categories of products) in different Warehouses, Dispatching of the stocks, Invoice generation, Financial reports, Customer relationship, Account management, Access control for various users.";
$folio[8]->description="ERP for a General store wherein the system helps to manage the Stocks (various categories and sub categories of products) in different Warehouses, Dispatching of the stocks, Invoice generation, Financial reports, Customer relationship, Account management, Access control for various users.";
$folio[9]->description="ERP for a General store wherein the system helps to manage the Stocks (various categories and sub categories of products) in different Warehouses, Dispatching of the stocks, Invoice generation, Financial reports, Customer relationship, Account management, Access control for various users.";
$folio[10]->description="ERP for a General store wherein the system helps to manage the Stocks (various categories and sub categories of products) in different Warehouses, Dispatching of the stocks, Invoice generation, Financial reports, Customer relationship, Account management, Access control for various users.";
$folio[11]->description="ERP for a General store wherein the system helps to manage the Stocks (various categories and sub categories of products) in different Warehouses, Dispatching of the stocks, Invoice generation, Financial reports, Customer relationship, Account management, Access control for various users.";
$folio[12]->description="ERP for a General store wherein the system helps to manage the Stocks (various categories and sub categories of products) in different Warehouses, Dispatching of the stocks, Invoice generation, Financial reports, Customer relationship, Account management, Access control for various users.";

$folio[0]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, Barcode Generator Plugin, Codeignitor, Data table, JQuery Validator, Select 2, MD5 Hash";
$folio[1]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, Barcode Generator Plugin, Codeignitor, Data table, JQuery Validator, Select 2, MD5 Hash";
$folio[2]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, Barcode Generator Plugin, Codeignitor, Data table, JQuery Validator, Select 2, MD5 Hash";
$folio[3]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, Barcode Generator Plugin, Codeignitor, Data table, JQuery Validator, Select 2, MD5 Hash";
$folio[4]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, Barcode Generator Plugin, Codeignitor, Data table, JQuery Validator, Select 2, MD5 Hash";
$folio[5]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, Barcode Generator Plugin, Codeignitor, Data table, JQuery Validator, Select 2, MD5 Hash";
$folio[6]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, Barcode Generator Plugin, Codeignitor, Data table, JQuery Validator, Select 2, MD5 Hash";
$folio[7]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, Barcode Generator Plugin, Codeignitor, Data table, JQuery Validator, Select 2, MD5 Hash";
$folio[8]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, Barcode Generator Plugin, Codeignitor, Data table, JQuery Validator, Select 2, MD5 Hash";
$folio[9]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, Barcode Generator Plugin, Codeignitor, Data table, JQuery Validator, Select 2, MD5 Hash";
$folio[10]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, Barcode Generator Plugin, Codeignitor, Data table, JQuery Validator, Select 2, MD5 Hash";
$folio[11]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, Barcode Generator Plugin, Codeignitor, Data table, JQuery Validator, Select 2, MD5 Hash";
$folio[12]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, Barcode Generator Plugin, Codeignitor, Data table, JQuery Validator, Select 2, MD5 Hash";
?>

<?php
 $this->load->helper('portfolio'); 
 echo createportfolio($folio); 
?>
