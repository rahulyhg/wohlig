<?php 

$folio[0]->header="Blenders Pride";
$folio[0]->img="bpft";
$folio[0]->description="Blenders Pride is a brand of Indian whisky.BPFT Is Self Developed Parallax Slider Site, beautiful transitions and animation perfectly blending to the feel. Uses extensive of jQuery and PHP making the website lite and simple.<br>Website url : www.bpft.in";
$folio[0]->technology="HTML5, CSS3, jQuery, PHP, Ajax, Bootstrap, Codeignitor";

$folio[1]->header="Lylaloves";
$folio[1]->img="lyla";
$folio[1]->description="Self Developed Slider, beautiful transitions and animation perfectly blending to the feel. Uses extensive of animations and ajax making the website lite and simple.<br>Website url : www.lylaloves.co.uk";
$folio[1]->technology="HTML5, CSS3, jQuery, PHP, Ajax, Bootstrap, Angularjs, Codeignitor";

$folio[2]->header="World7 Mediacraft";
$folio[2]->img="world7";
$folio[2]->description="A Complete Wordpress Site.World7 Mediacraft WebSite Making With The Help Of Wordpress.It's a Responsive site.Uses extensive of Animations and Graphics.Great Designing With Many Features.<br>Website url : www.world7mediacraft.com";
$folio[2]->technology="HTML5, CSS3, jQuery, PHP, Bootstrap, Wordpress";

$folio[3]->header="XDC India";
$folio[3]->img="xdc";
$folio[3]->description="XDC is a strategic branding and design consultancy with its reach across Pune, Mumbai,Delhi and Banglore.XDC India Site Based On Joomla. This website Is lite and simple With Responsive Feature.<br>Website url : www.xdcindia.com";
$folio[3]->technology="HTML5, CSS3, jQuery, PHP, Bootstrap, Joomla 2.5";

$folio[4]->header="BBJewellers";
$folio[4]->img="bbjeweller";
$folio[4]->description="BBJewellers Has Been One Of The Most Trusted Names For Jewellery. BBJewellers Is Self Developed site,beautiful transitions and animation perfectly blending to the feel. Uses HTML5, CSS3, Jquery.<br>Website url : www.bbjewellers.in";
$folio[4]->technology="HTML5, CSS3, jQuery, Bootstrap";


$folio[5]->header="India Value Homes";
$folio[5]->img="india";
$folio[5]->description="India Value Homes Was Set Up With an Objective of Helping People Across the World Access Pre Launch Information and buy Affordable Homes at the Click of a Button. It Is based On Angularjs With Codeignator.<br>Website url : www.indiavaluehomes.com";
$folio[5]->technology="HTML5, CSS3, jQuery, PHP, Ajax, Bootstrap, Angularjs, Codeignitor";

$folio[6]->header="Lodha Builders";
$folio[6]->img="lodha";
$folio[6]->description="Palava Site A Group Of Lodha Builders. Beautifull design by Wohlig.Simple slider.Uses extensive of animations.<br>Website url : www.palava.in";
$folio[6]->technology="HTML5, CSS3, jQuery, PHP, Ajax, Bootstrap, Angularjs, Codeignitor";

$folio[7]->header="Ziba Collection";
$folio[7]->img="ziba";
$folio[7]->description="Ziba Collection Is Same As lylaloves Site . Simple And Self Developed Slider, beautiful transitions and animation perfectly blending to the feel. Uses of animations making the website lite and simple.<br>Website url : www.zibacollection.in";
$folio[7]->technology="HTML5, CSS3, jQuery, PHP, Ajax, Bootstrap, Angularjs, Codeignitor";

$folio[8]->header="Rach Foundation";
$folio[8]->img="rach";
$folio[8]->description="RACH Foundation is a Non-proft Charitable Organization, Dedicated to Improving the Quality of Life of Under- Privileged Children and Families.Well Design With Great Graphics. Simple And Lite Animation Using CSS3.<br>Website url : www.rachfoundation.org";
$folio[8]->technology="HTML5, CSS3, jQuery, PHP, Ajax, Bootstrap, Angularjs, Codeignitor";


$folio[9]->header="Medscap India Award";
$folio[9]->img="medscap";
$folio[9]->description="The Medscapeindia has an express intent to unify the medical & healthcare community on causes common and dear to their larger goals. Uses extensive of animations and ajax making the website lite and simple.<br>Website url : www.msiawards.com";
$folio[9]->technology="HTML5, CSS3, jQuery, PHP, Ajax, Bootstrap, Angularjs, Codeignitor";

$folio[10]->header="My TDS Return";
$folio[10]->img="tax";
$folio[10]->description="My TDS Return Is Tax System Website Based On Codeignator.Self Developed Slider, beautiful transitions and animation perfectly blending to the feel. Uses extensive of animations making the website lite and simple.<br>Website url : www.mytdsreturn.com";
$folio[10]->technology="HTML5, CSS3, jQuery, PHP, Ajax, Bootstrap, Angularjs, Codeignitor";





$folio[11]->header="Designers Group";
$folio[11]->img="designers";
$folio[11]->description="This website contains many number of pages, developed with an admin panel where the admin can make all the website changes through the adminpanel. The Intro, Portfolio, Media Page are designed and developed on HTML5. Entire website including the animations are compatible on mobile devices too.";
$folio[11]->technology="HTML5, CSS3, jQuery, K2, PHP, Mootool, Joomla 2.5, Ajax";


$folio[12]->header="Golf Factory";
$folio[12]->img="golf";
$folio[12]->description="A complete e-commerce website with features like, cart, payment gateway, magic zoom on images, product catalog, discount coupons, sales, shipping, reports. Website also molds itself to a mobile website on mobile phones with more easy and user friendly navigation, events etc. ";
$folio[12]->technology="HTML5, CSS3, jQuery, Prototype, PHP, Magento, Magic Zoom, Ajax, Bootstrap";


$folio[13]->header="Int Advertising";
$folio[13]->img="int";
$folio[13]->description="A completely innovative web layout, unconventional web animations, along with admin panel for the client to manage their portfolio, Testimonial and many more. The portfolio of the website is self-developed gallery with backend management of the portfolio.";
$folio[13]->technology="HTML5, CSS3, jQuery, PHP, jQuery Masonry, Codeignitor";


$folio[14]->header="Ispirare Accessories";
$folio[14]->img="ispirare";
$folio[14]->description="Innovative design with background web slider and beautiful transitions and animation perfectly blending to the feel. This website is an example of a single page which is utilized for a website site using creative navigation and animations.";
$folio[14]->technology="HTML5, CSS3, jQuery, PHP, Super Slides";


$folio[15]->header="Lashkaria Group";
$folio[15]->img="lashkaria";
$folio[15]->description="This website contains many number of pages, developed with an admin panel where the admin can make all the website changes through the adminpanel. Website also molds itself to a mobile website on mobile phones with more easy and user friendly navigation, events etc. Background image transition is enhancing the UI.";
$folio[15]->technology="HTML5, CSS3, jQuery, K2, PHP, Mootool, Joomla 2.5, Ajax, Bootstrap";


$folio[16]->header="Orange Stone";
$folio[16]->img="orgstn";
$folio[16]->description="Self Developed Slider, beautiful transitions and animation perfectly blending to the feel. Uses extensive of animations and ajax making the website lite and simple.";
$folio[16]->technology="HTML5, CSS3, jQuery, PHP, Ajax";

$folio[17]->header="Furnicheer";
$folio[17]->img="furnicheer";
$folio[17]->description="Furnicheer is contemporary, clean lined, simple, warm and uncluttered. Uses extensive of animations making the website lite and simple.";
$folio[17]->technology="HTML5, CSS3, jQuery, PHP";








?>

<?php
 $this->load->helper('portfolio'); 
 echo createportfolio($folio); 
?>
