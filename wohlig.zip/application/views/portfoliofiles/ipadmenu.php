<?php 

$folio[0]->header="Dashboard View on iPad";
$folio[1]->header="Add Retailer View on iPad";
$folio[2]->header="Short By retailer View on iPad Menu";
$folio[3]->header="Products View on iPad";
$folio[4]->header="Products Details View on iPad";
$folio[5]->header="Products Image View on iPad";
$folio[6]->header="Category List on iPad ";
$folio[7]->header="Order List of iPad ";
$folio[8]->header="Order Confirmation on iPad ";
$folio[9]->header="Backend on iPad ";
$folio[10]->header="Backend Dashboard on iPad ";
$folio[11]->header="Backend User on iPad ";
$folio[12]->header="Backend Area on iPad ";
$folio[13]->header="Backend city on iPad ";
$folio[14]->header="Backend Distributor on iPad ";
$folio[15]->header="Backend Order on iPad ";
$folio[16]->header="Backend Product on iPad ";
$folio[17]->header="Backend Retailer on iPad ";
$folio[18]->header="Backend Product on iPad ";

$folio[0]->img="pad1";
$folio[1]->img="pad2";
$folio[2]->img="pad3";
$folio[3]->img="pad4";
$folio[4]->img="pad5";
$folio[5]->img="pad6";
$folio[6]->img="pad7";
$folio[7]->img="pad8";
$folio[8]->img="pad9";
$folio[9]->img="pad10";
$folio[10]->img="pad11";
$folio[11]->img="pad12";
$folio[12]->img="pad13";
$folio[13]->img="pad14";
$folio[14]->img="pad15";
$folio[15]->img="pad16";
$folio[16]->img="pad17";
$folio[17]->img="pad18";
$folio[18]->img="pad19";

$folio[0]->description="This Is Dashboard View On Ipad. Here In Dashboard Show The Login Information With Feild Mode, My Order, Last Retailer Option . At End Of dashboard view Showing Daily And Monthly Tally.";
$folio[1]->description="order Manegment is primarily made for Sales and customer. Easy interactivity between the Sales, Retailers,  attendant and the guest is the main feature of this product with a personalised touch.";
$folio[2]->description="order manegment given a best feature for see tha retailers details.you can see the retailrs details by shorting.";
$folio[3]->description="order manegment providing product view. here you can see the products View like name, code, price, quantity, Amount, photos.";
$folio[4]->description="Product Details View Provide Complete Details About Products.";
$folio[5]->description="ipad view on order manegment giving product picture view with full screen feature.";
$folio[6]->description="another best feature of order manegment is showing category list. You Can easly Distinguish by category.ans access the details.";
$folio[7]->description="order manegment providing order list with details.";
$folio[8]->description="order confirmation view showing the order history.in this, product name, product quantity, amount, MRP shows.";
$folio[9]->description="Backend dashboard View Of order manegment showing top ten products on dashboard. and other side showing last login status with daily sale and daily total amount.";
$folio[10]->description="second view of dashborad shoe the pie chart details.daily sales quantity amount graph and sales person quantity graph.";
$folio[11]->description="Second option in backend is user details view. in user details user name, user email, access level, mobile number, zone showing.";
$folio[12]->description="another option is area details. showing area name, city, distributor.";
$folio[13]->description="in this view you can see city list with all details.";
$folio[14]->description="in this view you can see distributor list with all details.";
$folio[15]->description="another option is order lists details. showing retailer, sales, amount, quantity.";
$folio[16]->description="Product view details. it's show product name with description, code, category, MRP.";
$folio[17]->description="retailers page show tha retailers details.";
$folio[18]->description="state view showing state details.";



$folio[0]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, ionic, Jquery Mobile, PhoneGap, angularjs, JQuery Validator, Select 2, MD5 Hash, Adobe Photoshop, Adobe Illustrator.";
$folio[1]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, ionic, Jquery Mobile, PhoneGap, angularjs, JQuery Validator, Select 2, MD5 Hash, Adobe Photoshop, Adobe Illustrator.";
$folio[2]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, ionic, Jquery Mobile, PhoneGap, angularjs, JQuery Validator, Select 2, MD5 Hash, Adobe Photoshop, Adobe Illustrator.";
$folio[3]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, ionic, Jquery Mobile, PhoneGap, angularjs, JQuery Validator, Select 2, MD5 Hash, Adobe Photoshop, Adobe Illustrator.";
$folio[4]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, ionic, Jquery Mobile, PhoneGap, angularjs, JQuery Validator, Select 2, MD5 Hash, Adobe Photoshop, Adobe Illustrator.";
$folio[5]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, ionic, Jquery Mobile, PhoneGap, angularjs, JQuery Validator, Select 2, MD5 Hash, Adobe Photoshop, Adobe Illustrator.";
$folio[6]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, ionic, Jquery Mobile, PhoneGap, angularjs, JQuery Validator, Select 2, MD5 Hash, Adobe Photoshop, Adobe Illustrator.";
$folio[7]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, ionic, Jquery Mobile, PhoneGap, angularjs, JQuery Validator, Select 2, MD5 Hash, Adobe Photoshop, Adobe Illustrator.";
$folio[8]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, ionic, Jquery Mobile, PhoneGap, angularjs, JQuery Validator, Select 2, MD5 Hash, Adobe Photoshop, Adobe Illustrator.";
$folio[9]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, ionic, Jquery Mobile, PhoneGap, angularjs, JQuery Validator, Select 2, MD5 Hash, Adobe Photoshop, Adobe Illustrator.";
$folio[10]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, ionic, Jquery Mobile, PhoneGap, angularjs, JQuery Validator, Select 2, MD5 Hash, Adobe Photoshop, Adobe Illustrator.";
$folio[11]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, ionic, Jquery Mobile, PhoneGap, angularjs, JQuery Validator, Select 2, MD5 Hash, Adobe Photoshop, Adobe Illustrator.";
$folio[12]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, ionic, Jquery Mobile, PhoneGap, angularjs, JQuery Validator, Select 2, MD5 Hash, Adobe Photoshop, Adobe Illustrator.";
$folio[13]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, ionic, Jquery Mobile, PhoneGap, angularjs, JQuery Validator, Select 2, MD5 Hash, Adobe Photoshop, Adobe Illustrator.";
$folio[14]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, ionic, Jquery Mobile, PhoneGap, angularjs, JQuery Validator, Select 2, MD5 Hash, Adobe Photoshop, Adobe Illustrator.";
$folio[15]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, ionic, Jquery Mobile, PhoneGap, angularjs, JQuery Validator, Select 2, MD5 Hash, Adobe Photoshop, Adobe Illustrator.";
$folio[16]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, ionic, Jquery Mobile, PhoneGap, angularjs, JQuery Validator, Select 2, MD5 Hash, Adobe Photoshop, Adobe Illustrator.";
$folio[17]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, ionic, Jquery Mobile, PhoneGap, angularjs, JQuery Validator, Select 2, MD5 Hash, Adobe Photoshop, Adobe Illustrator.";
$folio[18]->technology="HTML 5, CSS 3, JQuery, Ajax, PHP 5, MYSQL, Bootsrap, ionic, Jquery Mobile, PhoneGap, angularjs, JQuery Validator, Select 2, MD5 Hash, Adobe Photoshop, Adobe Illustrator.";


?>

<?php
 $this->load->helper('portfolio'); 
 echo createportfolio($folio); 
?>
