<?php 
	$this->load->view('pages/header');
	$this->load->view('pages/'.$page);
	$this->load->view('pages/footer');
?>